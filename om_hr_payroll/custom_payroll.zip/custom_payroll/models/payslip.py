from odoo import models, fields, api

class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    x_salary_pay_date = fields.Date(string="Salary Pay Date")

    x_total_working_days = fields.Float(string="Total Working Days", compute="_compute_days", store=True)
    x_paid_days = fields.Float(string="Paid Days", compute="_compute_days", store=True)
    x_paid_leave = fields.Float(string="Paid Leave", compute="_compute_days", store=True)
    x_unpaid_leave = fields.Float(string="Unpaid Leave", compute="_compute_days", store=True)
    x_leave_balance = fields.Float(string="Leave Balance", compute="_compute_days", store=True)

    carry_forward = fields.Float(string="Carry Forward Leaves")

    @api.depends('worked_days_line_ids.number_of_days', 'carry_forward')
    def _compute_days(self):
        for slip in self:
            total_days = 0
            paid_days = 0
            paid_leave = 0
            unpaid_leave = 0

            for line in slip.worked_days_line_ids:
                if line.code == 'WORK100':
                    total_days += line.number_of_days
                    paid_days += line.number_of_days

                elif line.code == 'LOP':
                    unpaid_leave += abs(line.number_of_days)

                elif line.code == 'PAID':
                    paid_leave += line.number_of_days

            monthly_leave = 1
            leaves_taken = unpaid_leave + paid_leave

            slip.x_leave_balance = slip.carry_forward + monthly_leave - leaves_taken
            slip.x_total_working_days = total_days
            slip.x_paid_days = paid_days
            slip.x_paid_leave = paid_leave
            slip.x_unpaid_leave = unpaid_leave

    def compute_sheet(self):
        res = super().compute_sheet()

        # Force recompute after salary calculation
        for slip in self:
            slip._compute_days()

        return res